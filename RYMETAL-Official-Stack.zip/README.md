# RY-METAL Cookware Accessories Website

This is a professional B2B landing page built with Astro and Tailwind CSS.

## 🚀 How to Deploy

### 1. Upload to GitHub
1. Create a new repository on GitHub named `ry-metal-site`.
2. Follow these commands in your terminal:
   ```bash
   git init
   git add .
   git commit -m "initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/ry-metal-site.git
   git push -u origin main
   ```

### 2. Connect to Cloudflare Pages
1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com/).
2. Navigate to **Workers & Pages** > **Create application** > **Pages**.
3. Connect your GitHub account and select `ry-metal-site`.
4. Build settings:
   - Framework preset: **Astro**
   - Build command: `npm run build`
   - Output directory: `dist`
5. Click **Save and Deploy**.

### 3. Setup Custom Domain (Namecheap)
1. In Cloudflare Pages, go to **Custom domains**.
2. Add your domain bought from Namecheap.
3. Follow the instructions to update your DNS records on Namecheap.

## 🛠 Tech Stack
- **Framework**: Astro 4.0
- **Styling**: Tailwind CSS
- **Deployment**: Cloudflare Pages

## ✉️ Contact
For inquiries, please update the form action or integrate with a service like Formspree.
